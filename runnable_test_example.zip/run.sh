DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
java -cp "autotester.jar;./yed-3.14.4/yed.jar" "espirit.mpoloczek.Launcher" "B.A.A.B" "$DIR/yEd_autotest.properties" "."
$SHELL